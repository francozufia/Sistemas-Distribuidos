package com.chat.Chat.model;

public record Mensaje(String nombre, String contenido) {

}
